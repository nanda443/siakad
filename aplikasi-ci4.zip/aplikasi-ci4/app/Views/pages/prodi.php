<div class="col-md-12">
    <div class="white_shd full margin_bottom_30">
        <div class="full graph_head">
            <div class="heading1 margin_0">
                <h2><?= $judul; ?></h2>
            </div>
        </div>
        <div class="table_section padding_infor_info pt-2">
            <div class="table-responsive-sm">
                <!-- Button trigger modal -->
                <button type="button" class="btn btn-primary mb-2" data-bs-toggle="modal" data-bs-target="#exampleModal">
                    Tambah Prodi
                </button>

                <!-- Modal -->
                <?php if (session()->getFlashdata('pesan')) : ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?= session()->getFlashdata('pesan'); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <?php if (session()->getFlashdata('gagal')) : ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?= session()->getFlashdata('gagal'); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>

                <?php endif; ?>

                <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Tambah Program Studi</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form method="post" action="/prodi/save">
                                    <div class="mb-3">
                                        <label for="kode_prodi" class="form-label">Kode Program Studi</label>
                                        <input type="text" class="form-control" id="kode_prodi" name="kode_prodi">
                                    </div>
                                    <div class="mb-3">
                                        <label for="nama_prodi" class="form-label">Nama Program</label>
                                        <input type="text" class="form-control" id="nama_prodi" name="nama_prodi">
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                        <button type="submit" class="btn btn-primary">Simpan</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>


                <table class="table">
                    <thead>
                        <tr class="text-center">
                            <th>No</th>
                            <th>Kode Program Studi</th>
                            <th>Program Studi</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1;
                        foreach ($prodi as $row) : ?>
                            <tr class="text-center">
                                <td><?= $i; ?></td>
                                <td><?= $row['kode_prodi']; ?></td>
                                <td><?= $row['nama_prodi']; ?></td>
                                <td>
                                    <button data-bs-toggle="modal" data-bs-target="#editModal<?= $row['id_prodi']; ?>" class="btn btn-warning btn-sm btn-flat tampilUbah"><i class="fa fa-pencil"></i></button>
                                    <a href="/prodi/delete/<?= $row['id_prodi']; ?>"><button class="btn btn-danger btn-sm btn-flat" onclick="return confirm('Apakah Anda Yakin?');"><i class="fa fa-trash"></i></button></a>
                                </td>
                            </tr>

                            <div class="modal fade" id="editModal<?= $row['id_prodi']; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel">Edit Program Studi</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form method="post" action="/prodi/update/<?= $row['id_prodi']; ?>">
                                                <input type="hidden" name="id_prodi" value="<?= $row['id_prodi']; ?>">
                                                <div class="mb-3">
                                                    <label for="kode_prodi" class="form-label">Kode Program Studi</label>
                                                    <input value="<?= $row['kode_prodi']; ?>" type="text" class="form-control" id="kode_prodi" name="kode_prodi">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="nama_prodi" class="form-label">Nama Program</label>
                                                    <input value="<?= $row['nama_prodi']; ?>" type="text" class="form-control" id="nama_prodi" name="nama_prodi">
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php $i++;
                        endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>