<div class="col-md-12">
    <div class="white_shd full margin_bottom_30">
        <div class="full graph_head">
            <div class="heading1 margin_0">
                <h2><?= $judul; ?></h2>
            </div>
        </div>
        <div class="table_section padding_infor_info pt-2">
            <div class="table-responsive-sm">
                <!-- Button trigger modal -->
                <button type="button" class="btn btn-primary mb-2" data-bs-toggle="modal" data-bs-target="#exampleModal">
                    Tambah Dosen
                </button>

                <!-- Modal -->
                <?php if (session()->getFlashdata('pesan')) : ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?= session()->getFlashdata('pesan'); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <?php if (session()->getFlashdata('gagal')) : ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?= session()->getFlashdata('gagal'); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>

                <?php endif; ?>

                <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Tambah Dosen</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form method="post" action="/dosen/save" enctype="multipart/form-data">
                                    <div class="mb-3">
                                        <label for="nidn" class="form-label">NIDN</label>
                                        <input type="text" class="form-control" id="nidn" name="nidn">
                                    </div>
                                    <div class="mb-3">
                                        <label for="nama_dosen" class="form-label">Nama Lengkap</label>
                                        <input type="text" class="form-control" id="nama_dosen" name="nama_dosen">
                                    </div>
                                    <div class="mb-3 custom-file">
                                        <input type="file" class="form-control custom-file-input" id="foto" name="foto" onchange="preview()">
                                        <label for="foto" class="form-label custom-file-label">Pilih Gambar</label>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                        <button type="submit" class="btn btn-primary">Simpan</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>


                <table class="table">
                    <thead>
                        <tr class="text-center">
                            <th>No</th>
                            <th>NIDN</th>
                            <th>Nama Lengkap</th>
                            <th>Foto</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1;
                        foreach ($dosen as $row) : ?>
                            <tr class="text-center">
                                <td><?= $i; ?></td>
                                <td><?= $row['nidn']; ?></td>
                                <td><?= $row['nama_dosen']; ?></td>
                                <td><img src="/images/foto/<?= $row['foto']; ?>" alt="" class="rounded-circle img-responsive" width="70px"></td>
                                <td>
                                    <button data-bs-toggle="modal" data-bs-target="#editModal<?= $row['id_dosen']; ?>" class="btn btn-warning btn-sm btn-flat"><i class="fa fa-pencil"></i></button>
                                    <a href="/dosen/delete/<?= $row['id_dosen']; ?>"><button class="btn btn-danger btn-sm btn-flat" onclick="return confirm('Apakah Anda Yakin?');"><i class="fa fa-trash"></i></button></a>
                                </td>
                            </tr>

                            <div class="modal fade" id="editModal<?= $row['id_dosen']; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel">Edit Dosen</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form method="post" action="/dosen/update/<?= $row['id_dosen']; ?>" enctype="multipart/form-data">
                                                <input type="hidden" name="id_dosen" value="<?= $row['id_dosen']; ?>">
                                                <input type="hidden" name="fotoLama" value="<?= $row['foto']; ?>">
                                                <div class="mb-3">
                                                    <label for="nidn" class="form-label">NIDN</label>
                                                    <input value="<?= $row['nidn']; ?>" type="text" class="form-control" id="nidn" name="nidn">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="nama_dosen" class="form-label">Nama Lengkap</label>
                                                    <input value="<?= $row['nama_dosen']; ?>" type="text" class="form-control" id="nama_dosen" name="nama_dosen">
                                                </div>
                                                <div class="mb-3 custom-file">
                                                    <input type="file" class="form-control custom-file-input" id="foto" name="foto" onchange="preview()">
                                                    <label for="foto" class="form-label custom-file-label"><?= $row['foto']; ?></label>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php $i++;
                        endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>