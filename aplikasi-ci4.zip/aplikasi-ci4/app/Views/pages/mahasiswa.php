<div class="col-md-12">
    <div class="white_shd full margin_bottom_30">
        <div class="full graph_head">
            <div class="heading1 margin_0">
                <h2><?= $judul; ?></h2>
            </div>
        </div>
        <div class="table_section padding_infor_info pt-2">
            <div class="table-responsive-sm">
                <!-- Button trigger modal -->
                <button type="button" class="btn btn-primary mb-2" data-bs-toggle="modal" data-bs-target="#exampleModal">
                    Tambah Mahasiswa
                </button>

                <!-- Modal -->
                <?php if (session()->getFlashdata('pesan')) : ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?= session()->getFlashdata('pesan'); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <?php if (session()->getFlashdata('gagal')) : ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?= session()->getFlashdata('gagal'); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>

                <?php endif; ?>

                <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Tambah Mahasiswa</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form method="post" action="/mahasiswa/save" enctype="multipart/form-data">
                                    <div class="mb-3">
                                        <label for="nim" class="form-label">NIM</label>
                                        <input type="text" class="form-control" id="nim" name="nim">
                                    </div>
                                    <div class="mb-3">
                                        <label for="nama_mhs" class="form-label">Nama Lengkap</label>
                                        <input type="text" class="form-control" id="nama_mhs" name="nama_mhs">
                                    </div>
                                    <div class="mb-3">
                                        <label for="id_prodi" class="form-label">Program Studi</label>
                                        <input type="text" class="form-control" id="id_prodi" name="id_prodi">
                                    </div>
                                    <div class="mb-3 custom-file">
                                        <input type="file" class="form-control custom-file-input" id="foto" name="foto" onchange="preview()">
                                        <label for="foto" class="form-label custom-file-label">Pilih Gambar</label>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                        <button type="submit" class="btn btn-primary">Simpan</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>


                <table class="table">
                    <thead>
                        <tr class="text-center">
                            <th>No</th>
                            <th>NIM</th>
                            <th>Nama Lengkap</th>
                            <th>Program Studi</th>
                            <th>Foto</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1;
                        foreach ($mahasiswa as $row) : ?>
                            <tr class="text-center">
                                <td><?= $i; ?></td>
                                <td><?= $row['nim']; ?></td>
                                <td><?= $row['nama_mhs']; ?></td>
                                <td><?= $row['id_prodi']; ?></td>
                                <td><img src="/images/foto/<?= $row['foto']; ?>" alt="" class="rounded-circle img-responsive" width="70px"></td>
                                <td>
                                    <button data-bs-toggle="modal" data-bs-target="#editModal<?= $row['id_mhs']; ?>" class="btn btn-warning btn-sm btn-flat"><i class="fa fa-pencil"></i></button>
                                    <a href="/mahasiswa/delete/<?= $row['id_mhs']; ?>"><button class="btn btn-danger btn-sm btn-flat" onclick="return confirm('Apakah Anda Yakin?');"><i class="fa fa-trash"></i></button></a>
                                </td>
                            </tr>

                            <div class="modal fade" id="editModal<?= $row['id_mhs']; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel">Edit Mahasiswa</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form method="post" action="/mahasiswa/update/<?= $row['id_mhs']; ?>" enctype="multipart/form-data">
                                                <input type="hidden" name="id_mhs" value="<?= $row['id_mhs']; ?>">
                                                <input type="hidden" name="fotoLama" value="<?= $row['foto']; ?>">
                                                <div class="mb-3">
                                                    <label for="nim" class="form-label">NIM</label>
                                                    <input value="<?= $row['nim']; ?>" type="text" class="form-control" id="nim" name="nim">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="nama_mhs" class="form-label">Nama Lengkap</label>
                                                    <input value="<?= $row['nama_mhs']; ?>" type="text" class="form-control" id="nama_mhs" name="nama_mhs">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="id_prodi" class="form-label">Program Studi</label>
                                                    <input value="<?= $row['id_prodi']; ?>" type="text" class="form-control" id="id_prodi" name="id_prodi">
                                                </div>
                                                <div class="mb-3 custom-file">
                                                    <input type="file" class="form-control custom-file-input" id="foto" name="foto" onchange="preview()">
                                                    <label for="foto" class="form-label custom-file-label"><?= $row['foto']; ?></label>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php $i++;
                        endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>