<?php

namespace App\Controllers;

use App\Models\Mahasiswa_model;

class Mahasiswa extends BaseController
{
    protected $mahasiswaModel;
    public function __construct()
    {
        $this->mahasiswaModel = new Mahasiswa_model();
    }

    public function index()
    {

        $user = session()->get('user');
        $mahasiswa = $this->mahasiswaModel->findAll();
        $data = [
            'judul' => 'Mahasiswa',
            'mahasiswa' => $mahasiswa,
            'user' => $user
        ];

        echo view('layout/header', $data);
        echo view('pages/mahasiswa', $data);
        echo view('layout/footer');
    }

    public function save()
    {
        //validasi input
        if (!$this->validate([
            'nim' => 'required|is_unique[tbl_mhs.nim]',
            'nama_mhs' => 'required',
            'id_prodi' => 'required',
            'foto' => 'uploaded[foto]|max_size[foto,5024]|is_image[foto]|mime_in[foto,image/jpg,image/jpeg,image/png]'
        ])) {
            session()->setFlashdata('gagal', 'Gagal Menambahkan Mahasiswa');
            return redirect()->to('/mahasiswa');
        }

        //ambil gambar
        $fileFoto = $this->request->getFile('foto');
        //pindahkan gambar
        $fileFoto->move('images/foto');
        //ambil nama file
        $namaFoto = $fileFoto->getName();


        $this->mahasiswaModel->save([
            'nim' => $this->request->getVar('nim'),
            'nama_mhs' => $this->request->getVar('nama_mhs'),
            'id_prodi' => $this->request->getVar('id_prodi'),
            'foto' => $namaFoto
        ]);

        session()->setFlashdata('pesan', 'Berhasil Menambahkan Mahasiswa');
        return redirect()->to('/mahasiswa');
    }

    public function delete($id_mhs)
    {
        //cari gambar berdasarkan id
        $mahasiswa = $this->mahasiswaModel->find($id_mhs);
        //hapus gambar
        unlink('images/foto/' . $mahasiswa['foto']);
        $this->mahasiswaModel->delete($id_mhs);
        session()->setFlashdata('pesan', 'Berhasil Menghapus Mahasiswa');
        return redirect()->to('/mahasiswa');
    }

    public function update($id_mhs)
    {
        //validasi input
        if (!$this->validate([
            'nim' => 'required',
            'nama_mhs' => 'required',
            'id_prodi' => 'required',
            'foto' => 'max_size[foto,5024]|is_image[foto]|mime_in[foto,image/jpg,image/jpeg,image/png]'
        ])) {
            session()->setFlashdata('gagal', 'Gagal Mengedit Mahasiswa');
            return redirect()->to('/mahasiswa');
        }

        //ambil gambar
        $fileFoto = $this->request->getFile('foto');
        //cek gambar apakah berubah
        if ($fileFoto->getError() == 4) {
            $namaFoto = $this->request->getVar('fotoLama');
        } else {
            $namaFoto = $fileFoto->getName();
            //pindahkan gambar
            $fileFoto->move('images/foto');
            //hapus gambar lama
            unlink('images/foto/' . $this->request->getVar('fotoLama'));
        }

        $this->mahasiswaModel->save([
            'id_mhs' => $id_mhs,
            'nim' => $this->request->getVar('nim'),
            'nama_mhs' => $this->request->getVar('nama_mhs'),
            'id_prodi' => $this->request->getVar('id_prodi'),
            'foto' => $namaFoto
        ]);

        session()->setFlashdata('pesan', 'Berhasil Mengedit Mahasiswa');
        return redirect()->to('/mahasiswa');
    }
}
