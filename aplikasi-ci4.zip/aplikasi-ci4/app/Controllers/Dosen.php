<?php

namespace App\Controllers;

use App\Models\Dosen_model;

class Dosen extends BaseController
{
    protected $dosenModel;
    public function __construct()
    {
        $this->dosenModel = new Dosen_model();
    }

    public function index()
    {
        $dosen = $this->dosenModel->findAll();
        $data = [
            'judul' => 'Dosen',
            'dosen' => $dosen
        ];

        echo view('layout/header', $data);
        echo view('pages/dosen', $data);
        echo view('layout/footer');
    }

    public function save()
    {
        //validasi input
        if (!$this->validate([
            'nidn' => 'required|is_unique[tbl_dosen.nidn]',
            'nama_dosen' => 'required',
            'foto' => 'uploaded[foto]|max_size[foto,5024]|is_image[foto]|mime_in[foto,image/jpg,image/jpeg,image/png]'
        ])) {
            session()->setFlashdata('gagal', 'Gagal Menambahkan dosen');
            return redirect()->to('/dosen');
        }

        //ambil gambar
        $fileFoto = $this->request->getFile('foto');
        //pindahkan gambar
        $fileFoto->move('images/foto');
        //ambil nama file
        $namaFoto = $fileFoto->getName();


        $this->dosenModel->save([
            'nidn' => $this->request->getVar('nidn'),
            'nama_dosen' => $this->request->getVar('nama_dosen'),
            'foto' => $namaFoto
        ]);

        session()->setFlashdata('pesan', 'Berhasil Menambahkan Dosen');
        return redirect()->to('/dosen');
    }

    public function delete($id_dosen)
    {
        //cari gambar berdasarkan id
        $dosen = $this->dosenModel->find($id_dosen);
        //hapus gambar
        unlink('images/foto/' . $dosen['foto']);
        $this->dosenModel->delete($id_dosen);
        session()->setFlashdata('pesan', 'Berhasil Menghapus Dosen');
        return redirect()->to('/dosen');
    }

    public function update($id_dosen)
    {
        //validasi input
        if (!$this->validate([
            'nidn' => 'required',
            'nama_dosen' => 'required',
            'foto' => 'max_size[foto,5024]|is_image[foto]|mime_in[foto,image/jpg,image/jpeg,image/png]'
        ])) {
            session()->setFlashdata('gagal', 'Gagal Mengedit Dosen');
            return redirect()->to('/dosen');
        }

        //ambil gambar
        $fileFoto = $this->request->getFile('foto');
        //cek gambar apakah berubah
        if ($fileFoto->getError() == 4) {
            $namaFoto = $this->request->getVar('fotoLama');
        } else {
            $namaFoto = $fileFoto->getName();
            //pindahkan gambar
            $fileFoto->move('images/foto');
            //hapus gambar lama
            unlink('images/foto/' . $this->request->getVar('fotoLama'));
        }

        $this->dosenModel->save([
            'id_dosen' => $id_dosen,
            'nidn' => $this->request->getVar('nidn'),
            'nama_dosen' => $this->request->getVar('nama_dosen'),
            'foto' => $namaFoto
        ]);

        session()->setFlashdata('pesan', 'Berhasil Mengedit Dosen');
        return redirect()->to('/dosen');
    }
}
