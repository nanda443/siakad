<?php

namespace App\Controllers;

use App\Models\Prodi_model;

class Prodi extends BaseController
{
    protected $prodiModel;
    public function __construct()
    {
        $this->prodiModel = new Prodi_model();
    }

    public function index()
    {
        $prodi = $this->prodiModel->findAll();
        $data = [
            'judul' => 'Program Studi',
            'prodi' => $prodi
        ];

        echo view('layout/header', $data);
        echo view('pages/prodi', $data);
        echo view('layout/footer');
    }

    public function save()
    {
        //validasi input
        if (!$this->validate([
            'kode_prodi' => 'required|is_unique[tbl_prodi.kode_prodi]',
            'nama_prodi' => 'required'
        ])) {
            session()->setFlashdata('gagal', 'Gagal Menambahkan Program Studi');
            return redirect()->to('/prodi');
        }

        $this->prodiModel->save([
            'kode_prodi' => $this->request->getVar('kode_prodi'),
            'nama_prodi' => $this->request->getVar('nama_prodi')
        ]);

        session()->setFlashdata('pesan', 'Berhasil Menambahkan Program Studi');
        return redirect()->to('/prodi');
    }

    public function delete($id_prodi)
    {
        $this->prodiModel->delete($id_prodi);
        session()->setFlashdata('pesan', 'Berhasil Menghapus Program Studi');
        return redirect()->to('/prodi');
    }

    public function update($id)
    {
        //validasi input
        if (!$this->validate([
            'kode_prodi' => 'required',
            'nama_prodi' => 'required'
        ])) {
            session()->setFlashdata('gagal', 'Gagal Mengedit Program Studi');
            return redirect()->to('/prodi');
        }

        $this->prodiModel->save([
            'id_prodi' => $id,
            'kode_prodi' => $this->request->getVar('kode_prodi'),
            'nama_prodi' => $this->request->getVar('nama_prodi')
        ]);

        session()->setFlashdata('pesan', 'Berhasil Mengedit Program Studi');
        return redirect()->to('/prodi');
    }
}
