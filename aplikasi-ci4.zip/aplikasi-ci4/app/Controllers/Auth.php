<?php

namespace App\Controllers;

use App\Models\Auth_model;

class Auth extends BaseController
{
    protected $authModel;
    public function __construct()
    {
        $this->authModel = new Auth_model();
    }

    public function index()
    {
        
        $data = [
            'judul' => 'Login'
        ];

        return view('pages/login', $data);
    }

    public function login()
    {
        //lakukan validasi input
        $this->validate([
            'username' => 'required',
            'password' => 'required'
        ]);

        //ambil data
        $username = $this->request->getVar('username');
        $password = $this->request->getVar('password');
        //ambil data dari database
        $user = $this->authModel->where('username', $username)->first();


        //cek apakah password sesuai
        if ($user && $password === $user['password']) {
            //jika login berhasil
            session()->set('user', $user);
            session()->set('login', true);
            session()->set('userId', $user['id_user']);
            return redirect()->to('/mahasiswa');
        } else {
            session()->setFlashdata('pesan', 'Username atau Password Salah');
            return redirect()->to('/auth');
        }
    }

    public function logout()
    {
        //hapus session
        session()->remove(['login', 'userId']);
        return redirect()->to('/auth');
    }
}
