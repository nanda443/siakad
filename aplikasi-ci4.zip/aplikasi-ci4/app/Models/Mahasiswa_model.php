<?php

namespace App\Models;

use CodeIgniter\Model;

class Mahasiswa_model extends Model
{
    protected $table = 'tbl_mhs';
    protected $primaryKey = 'id_mhs';
    protected $allowedFields = ['nim', 'nama_mhs', 'id_prodi', 'foto'];
    protected $useTimestamps = true;
}
