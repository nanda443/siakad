<?php

namespace App\Models;

use CodeIgniter\Model;

class Dosen_model extends Model
{
    protected $table = 'tbl_dosen';
    protected $primaryKey = 'id_dosen';
    protected $allowedFields = ['nidn', 'nama_dosen', 'foto'];
    protected $useTimestamps = true;
}
